exports.handler = async (event) => {
    console.log('TicketDesk Lambda Notification Event Processed:', JSON.stringify(event));
    return { statusCode: 200, body: JSON.stringify({ message: 'Success' }) };
};
